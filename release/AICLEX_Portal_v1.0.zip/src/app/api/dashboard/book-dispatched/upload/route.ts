import { NextRequest, NextResponse } from "next/server";
import { auth } from "@/auth";
import prisma from "@/lib/prisma";
import * as XLSX from "xlsx";

export async function POST(req: NextRequest) {
  try {
    const session = await auth();
    const role = session?.user?.role as any;
    if (!session || (role !== "ADMIN" && role !== "VENDOR")) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const formData = await req.formData();
    const file = formData.get("file") as File;
    
    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 });
    }

    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);

    // Parse Excel/CSV
    const workbook = XLSX.read(buffer, { type: "buffer" });
    const allResolvedIds: string[] = [];
    const rawRows: any[] = [];

    for (const sheetName of workbook.SheetNames) {
      const worksheet = workbook.Sheets[sheetName];
      const data: any[] = XLSX.utils.sheet_to_json(worksheet, { defval: "" });

      for (const row of data) {
        const employeeId = String(row["Employee Id"] || row["Employee ID"] || "").trim();
        const whatsappNo = String(row["Whatsapp No"] || row["Whatsapp"] || "").trim();
        const mobileNo = String(row["Mobile No"] || row["Mobile"] || row["Personal Mobile No"] || "").trim();
        
        rawRows.push({ employeeId, whatsappNo, mobileNo });
      }
    }

    // Resolve IDs from Phone Numbers if missing
    for (const row of rawRows) {
        if (row.employeeId) {
            allResolvedIds.push(row.employeeId);
        } else if (row.whatsappNo || row.mobileNo) {
            // Find by phone in Master List
            const match = await prisma.bookDeliveryMaster.findFirst({
                where: {
                    OR: [
                        { whatsappNo: row.whatsappNo || undefined },
                        { personalMobileNo: row.mobileNo || undefined },
                        { officeMobileNo: row.mobileNo || undefined },
                    ]
                },
                select: { employeeId: true }
            });
            if (match) allResolvedIds.push(match.employeeId);
        }
    }

    const uniqueIds = Array.from(new Set(allResolvedIds));

    if (uniqueIds.length === 0) {
      return NextResponse.json({ error: "No valid employee records or phone matches found in file" }, { status: 400 });
    }

    const finalData = uniqueIds.map(id => ({ employeeId: id }));

    // High-performance batch insertion for dispatched list
    // We use skipDuplicates to avoid errors if someone is already in the list
    const result = await prisma.bookDispatched.createMany({
        data: finalData,
        skipDuplicates: true,
    });

    return NextResponse.json({ 
        success: true, 
        message: `Successfully processed ${finalData.length} records. ${result.count} new recipients added to Dispatched list.` 
    });

  } catch (error: any) {
    console.error("Dispatched Upload Error:", error);
    return NextResponse.json({ error: error.message || "Failed to process dispatched file" }, { status: 500 });
  }
}
