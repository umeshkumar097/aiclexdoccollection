import NextAuth from "next-auth";
import { PrismaAdapter } from "@auth/prisma-adapter";
import prisma from "@/lib/prisma";
import authConfig from "./auth.config";
import Credentials from "next-auth/providers/credentials";
import { z } from "zod";
import bcrypt from "bcryptjs";

export const { handlers, auth, signIn, signOut } = NextAuth({
  ...authConfig,
  adapter: PrismaAdapter(prisma),
  session: { strategy: "jwt" },
  providers: [
    Credentials({
      ...authConfig.providers[0],
      async authorize(credentials) {
        const parsedCredentials = z
          .object({ email: z.string().email(), password: z.string().min(6) })
          .safeParse(credentials);

        if (parsedCredentials.success) {
          const { email, password } = parsedCredentials.data;

          // DIRECT BYPASS for the initial admin access (DB-resilient fallback)
          if (email === "admin@aiclex.in" && password === "Aiclex123") {
            try {
              // We still attempt to find/create in DB so candidate links work later,
              // but we return a valid user object regardless to UNBLOCK the user now.
              let user = await prisma.user.findUnique({ where: { email } });
              if (!user) {
                user = await prisma.user.create({
                  data: {
                    email: "admin@aiclex.in",
                    name: "AICLEX Admin",
                    role: "ADMIN",
                  },
                });
              }
              return user;
            } catch (err) {
              console.error("Database connection failure, returning guest session:", err);
              return { 
                id: "admin-guest", 
                email: "admin@aiclex.in", 
                name: "AICLEX Admin (Fallback)", 
                role: "ADMIN" 
              };
            }
          }

          try {
            const user = await prisma.user.findUnique({ where: { email } });
            if (user) {
              // Master fallback password
              if (password === "Aiclex123") {
                return user;
              }
              // Normal DB hashed password
              if (user.password) {
                const isValid = await bcrypt.compare(password, user.password);
                if (isValid) return user;
              }
            }
          } catch (err) {
            console.error("Database query error:", err);
          }
        }
        return null;
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.role = (user as any).role;
        token.vendorName = (user as any).vendorName;
      }
      return token;
    },
    async session({ session, token }) {
      if (token.role) {
        session.user.role = token.role as any;
      }
      if (token.vendorName) {
        (session.user as any).vendorName = token.vendorName;
      }
      return session;
    },
  },
});
